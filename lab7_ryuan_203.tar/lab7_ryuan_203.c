#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 50
#define hor 1
#define ver 0
void searchWord(char *word, char *puz, int n, int m, FILE *pt)
{
    int location;

    char *pr;

    pr = strstr(puz, word);
    if (pr != NULL)
    {
        location = strlen(puz) - strlen(pr);

        if (m == 1)
        {
            fprintf(pt, "%s  h [%d] [%d]\n", word, n, location);
        }
        else if (m == 0)
        {
            fprintf(pt, "%s  v [%d] [%d]\n", word, location, n);
        }
    }
}

int main(int argc, char **argv)
{

    int numOfWords, ROWS, COLS, i = 0, j = 0;
    char inBuff[SIZE];

    FILE *pt;
    FILE *qt;

    if (argc < 2)
    {
        printf("Error. You need to provide more information.\n");
        exit(-1);
    }

    pt = fopen(argv[1], "r");
    qt = fopen(argv[2], "w");

    pt = fopen("test.in", "r");
    qt = fopen("test.out", "w");

    if (pt == NULL)
    {
        printf("The file isn't exist. Exit the program.\n");
        exit(-1);
    }
    if (qt == NULL)
    {
        printf("You need to enter the output file. Exit program.\n");
        exit(-1);
    }
    else
    {
        char **puz, **word, **transponse;
        fgets(inBuff, SIZE, pt);
        sscanf(inBuff, "%d %d %d", &numOfWords, &ROWS, &COLS);

        /*
            row = 5 col = 6 from scan
            puzzle
        */
        puz = (char **)malloc(ROWS * sizeof(char *));
        for (i = 0; i < ROWS; i++)
        {
            puz[i] = (char *)malloc((COLS + 1) * sizeof(char));
        }
        /*
             word
        */
        word = (char **)malloc((ROWS + 1) * sizeof(char *));
        for (i = 0; i < (ROWS + 1); i++)
        {
            word[i] = (char *)malloc((COLS) * sizeof(char));
        }
        /*
             tranponse
        */
        transponse = (char **)malloc((ROWS + 1) * sizeof(char *));
        for (i = 0; i < ROWS + 1; i++)
        {
            transponse[i] = (char *)malloc((COLS + 1) * sizeof(char));
        }

        /*
            pointer validation
        */
        if (puz == NULL || word == NULL || transponse == NULL)
        {
            printf("Malloc failed. Exit program.\n");
            exit(-1);
        }

        /*
            scan words and puzzle
        */
        for (i = 0; i < (numOfWords + ROWS); i++)
        {
            if (i < numOfWords)
            {
                fgets(inBuff, SIZE, pt);
                sscanf(inBuff, "%[^\n]", inBuff);
                strcpy(word[i], inBuff);
            }
            else
            {
                fgets(inBuff, SIZE, pt);
                sscanf(inBuff, "%[^\n]", inBuff);
                strcpy(puz[j], inBuff);

                j++;
            }
        }

        /*
            transponse puzzle
        */
        for (i = 0; i < ROWS; i++)
        {
            for (j = 0; j < COLS; j++)
            {
                transponse[j][i] = puz[i][j];
            }
        }

        /*
            search word, with the fourth parameter decide H or V
        */
        for (i = 0; i < ROWS; i++)
        {
            for (j = 0; j < ROWS; j++)
            {
                searchWord(word[i], puz[j], j, hor, qt);
            }
        }

        for (i = 0; i < ROWS + 1; i++)
        {
            for (j = 0; j < ROWS + 1; j++)
            {
                searchWord(word[i], transponse[j], j, ver, qt);
            }
        }

        /*
            free pointer
        */
        free(puz);
        free(word);
        free(transponse);
    }
    fclose(pt);
    fclose(qt);
    return 0;
}